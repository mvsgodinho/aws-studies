const ProductService = require('./ProductService');

module.exports = {
  ProductService,
};
