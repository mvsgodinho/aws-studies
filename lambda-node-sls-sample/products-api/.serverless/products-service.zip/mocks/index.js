const productsFindAll = require('./products-find-all.json');

module.exports = {
    productsFindAll,
};