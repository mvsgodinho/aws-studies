const ProductController = require('./ProductController');

module.exports = {
  ProductController,
};
